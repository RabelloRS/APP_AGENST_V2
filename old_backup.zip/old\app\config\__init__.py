"""
Módulo de configuração para agentes e tarefas
"""
