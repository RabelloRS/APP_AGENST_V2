"""
Módulo de gerenciamento de crews
"""
