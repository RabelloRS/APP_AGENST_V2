#!/usr/bin/env python3
"""
Teste simples para verificar a lógica de importação de ferramentas no workflow builder
"""

import yaml
from pathlib import Path

# Carregar dados de teste
agents_file_path = Path("app/config/agents.yaml")
tasks_file_path = Path("app/config/tasks.yaml")

if agents_file_path.exists():
    with open(agents_file_path, "r", encoding="utf-8") as f:
        agents_data = yaml.safe_load(f) or {}
else:
    print("❌ Arquivo agents.yaml não encontrado")
    agents_data = {}

if tasks_file_path.exists():
    with open(tasks_file_path, "r", encoding="utf-8") as f:
        tasks_data = yaml.safe_load(f) or {}
else:
    print("❌ Arquivo tasks.yaml não encontrado")
    tasks_data = {}

# Lista completa de ferramentas nativas do crewai_tools
native_crewai_tools = {
    'brave_search', 'serper_dev', 'exa_search', 'website_search', 'pdf_search', 
    'code_docs_search', 'serpapi_tool', 'serply_api_tool', 'linkup_search', 
    'browserbase_load', 'scrapfly_scrape_website', 'spider_tool', 'firecrawl', 
    'ai_mind', 'patronus', 'crewai_enterprise', 'databricks_query', 
    'qdrant_vector_search', 'weaviate_vector_search', 'snowflake_search', 
    'apify_actors', 'composio', 'multion', 'zapier_action', 'stagehand', 
    'github_search', 'tavily', 'csv_search', 'json_search', 'nl2sql', 
    'mysql_search', 'pg_search', 'file_read', 'file_writer', 'mdx_search', 
    'docx_search', 'code_interpreter', 'directory_read', 'selenium_scraping', 
    'patronus_eval', 'vision', 'llama_index'
}

print("🔍 Verificando ferramentas nos agentes...")
print()

for agent_name, agent_info in agents_data.items():
    tools = agent_info.get("tools", [])
    if tools:
        print(f"📋 {agent_name}:")
        for tool in tools:
            normalized_tool_name = tool.lower().replace('tool', '')
            if normalized_tool_name in native_crewai_tools:
                print(f"  ✅ {tool} -> NATIVA (crewai_tools)")
            else:
                print(f"  🔧 {tool} -> CUSTOM (app.utils.tools)")
        print()

print("✅ Teste concluído!") 