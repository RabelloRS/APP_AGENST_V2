Arquivos movidos para esta pasta não são mais utilizados no fluxo principal do projeto. Mantenha aqui apenas para histórico ou consulta eventual.
