#!/usr/bin/env python3
"""
Teste para verificar se as ferramentas que precisam de API keys estão sendo instanciadas corretamente
"""

import yaml
from pathlib import Path

# Carregar dados de teste
agents_file_path = Path("app/config/agents.yaml")

if agents_file_path.exists():
    with open(agents_file_path, "r", encoding="utf-8") as f:
        agents_data = yaml.safe_load(f) or {}
else:
    print("❌ Arquivo agents.yaml não encontrado")
    agents_data = {}

# Mapeamento de ferramentas que precisam de API keys
tools_requiring_api_keys = {
    'BraveSearchTool': 'BRAVE_API_KEY',
    'SerperDevTool': 'SERPER_API_KEY',
    'EXASearchTool': 'EXA_API_KEY',
    'PDFSearchTool': 'PDF_SEARCH_API_KEY',
    'WebsiteSearchTool': 'WEBSITE_SEARCH_API_KEY',
    'CodeDocsSearchTool': 'CODE_DOCS_API_KEY',
    'SerpAPITool': 'SERPAPI_API_KEY',
    'SerplyAPITool': 'SERPLY_API_KEY',
    'LinkupSearchTool': 'LINKUP_API_KEY',
    'BrowserbaseLoadTool': 'BROWSERBASE_API_KEY',
    'ScrapflyScrapeWebsiteTool': 'SCRAPFLY_API_KEY',
    'SpiderTool': 'SPIDER_API_KEY',
    'FirecrawlTool': 'FIRECRAWL_API_KEY',
    'AIMindTool': 'MINDSDB_API_KEY',
    'PatronusTool': 'PATRONUS_API_KEY',
    'CrewAIEnterpriseTool': 'CREWAI_ENTERPRISE_TOKEN',
    'DatabricksQueryTool': 'DATABRICKS_TOKEN',
    'QdrantVectorSearchTool': 'QDRANT_API_KEY',
    'WeaviateVectorSearchTool': 'WEAVIATE_API_KEY',
    'SnowflakeSearchTool': 'SNOWFLAKE_USER',
    'ApifyActorsTool': 'APIFY_API_TOKEN',
    'ComposioTool': 'COMPOSIO_API_KEY',
    'MultiOnTool': 'MULTION_API_KEY',
    'ZapierTool': 'ZAPIER_API_KEY',
    'StagehandTool': 'STAGEHAND_API_KEY',
    'GithubSearchTool': 'GITHUB_PAT',
    'TavilySearchTool': 'TAVILY_API_KEY',
}

print("🔍 Verificando ferramentas que precisam de API keys...")
print()

for agent_name, agent_info in agents_data.items():
    tools = agent_info.get("tools", [])
    if tools:
        print(f"📋 {agent_name}:")
        for tool in tools:
            if tool in tools_requiring_api_keys:
                api_key = tools_requiring_api_keys[tool]
                print(f"  🔑 {tool} -> Precisa de {api_key}")
            else:
                print(f"  ✅ {tool} -> Não precisa de API key")
        print()

print("✅ Teste concluído!") 