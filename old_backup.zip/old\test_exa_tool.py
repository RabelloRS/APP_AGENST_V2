#!/usr/bin/env python3
"""
Teste simples para verificar se o EXASearchTool pode ser instanciado corretamente
"""

import os
from dotenv import load_dotenv

# Carregar variáveis do arquivo .env
load_dotenv()

print("🔍 Testando instanciação do EXASearchTool...")
print()

# Verificar se a API key está disponível
exa_api_key = os.getenv('EXA_API_KEY')
if exa_api_key:
    print(f"✅ EXA_API_KEY encontrada: {exa_api_key[:10]}...")
else:
    print("❌ EXA_API_KEY não encontrada")
    exit(1)

try:
    # Tentar importar e instanciar o EXASearchTool
    from crewai_tools import EXASearchTool
    
    print("✅ EXASearchTool importado com sucesso")
    
    # Instanciar com a API key
    exa_tool = EXASearchTool(api_key=exa_api_key)
    print("✅ EXASearchTool instanciado com sucesso")
    
    # Testar uma busca simples
    print("🔍 Testando busca simples...")
    result = exa_tool._run(search_query="test")
    print(f"✅ Busca realizada com sucesso. Resultado: {type(result)}")
    
except ImportError as e:
    print(f"❌ Erro ao importar EXASearchTool: {e}")
except Exception as e:
    print(f"❌ Erro ao instanciar ou usar EXASearchTool: {e}")

print("\n✅ Teste concluído!") 